Free Download Source Code "Event_Management_System"

FIRST Download

1.XAMPP

2."TEXT EDITOR" NOTEPAD++ OR SUBLIME TEXT 3 / ETC.

3"Event_Management_System"

4. Download the zip file/ download winrar

5. Extract the file and copy "Event_Management_System" folder

6.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name event_db

6. Import event_db.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/Event_Management_System


**LOGIN DETAILS** 
Admin
user: admin
pass: admin123

****** https:1sourcecodr.blogspot.com ******
Subcribe my You tube Channel **** 1 Source code ****